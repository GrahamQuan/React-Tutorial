import React, { PureComponent } from 'react'

export default class Profile extends PureComponent {
  render() {
    return (
      <div>
        <h2>Profile</h2>
      </div>
    )
  }
}
