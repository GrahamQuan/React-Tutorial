import React, { PureComponent } from 'react'

export default class NoMatch extends PureComponent {
  render() {
    return (
      <div>
        <h2>NoMatch</h2>
      </div>
    )
  }
}
