import React, { PureComponent } from 'react'

export default class Login extends PureComponent {
  render() {
    return (
      <div>
        <h2>Login</h2>
      </div>
    )
  }
}
