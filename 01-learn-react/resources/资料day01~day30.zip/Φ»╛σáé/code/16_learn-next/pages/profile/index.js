import React, { memo } from 'react';

import Layout from './layout';

export default memo(function Profile() {
  return (
    <Layout>
      
    </Layout>
  )
})
